let a=11;


if(a%2===0){
    console.log("Even number")
}

else if (a%2!==0){
    console.log("odd number")
}

console.log()