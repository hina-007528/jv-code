let age=20;
var ali="heufeu"
if(age>=18){
    console.log("Eligible to vote")
}

else if(age<18){
    console.log("Not eligible to vote")
}
else{
    console.log("Invalid age")
}

// for loop

for(let i=5; i>0; i--){
    // console.log(i);

    if(i%2===0){
        console.log("Even number")
    }   


}

