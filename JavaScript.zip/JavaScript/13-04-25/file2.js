const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("Enter your name: ", function(name) {
  // You can use an if condition here too
  if (name.toLowerCase() === "ali") {
    console.log("Good boy");
  }
  
  console.log(name + " good boy");
  rl.close();
});
